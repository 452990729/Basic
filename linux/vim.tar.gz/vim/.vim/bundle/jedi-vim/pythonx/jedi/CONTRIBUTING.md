Pull Requests are great.

 1. Fork the Repo on github.
 2. If you are adding functionality or fixing a bug, please add a test!
 3. Add your name to AUTHORS.txt
 4. Push to your fork and submit a pull request.

**Try to use the PEP8 style guide** (and it's ok to have a line length of 100 characters).
